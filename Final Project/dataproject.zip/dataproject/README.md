Please press next page if page is blank. So should start on method.

A few pages might be blank, which I had difficulties deleting resulting in the order being disorganised when attempted.

Your notebooks kernal will need to have both python and sql kernals as there are a few visuals by sql using azure data studio and sanddance visualiser which did aide in plotting visuals in python, also some are 3d allowing for extra axis and variables.